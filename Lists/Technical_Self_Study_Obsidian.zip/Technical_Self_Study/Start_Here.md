# Start Here

Open [[Technical_Self_Study_Curriculum]] for the introduction and study stage links.

## Install in Obsidian

1. Extract the ZIP file.
2. Copy the entire Technical_Self_Study folder into your vault, or open it as a new vault.
3. Open Technical_Self_Study_Curriculum.
4. Select a stage, then select a course.

If you imported an earlier version, back up any personal notes before replacing its folder. This package contains the prepared curriculum, not edits you made in your vault.

## Graph structure

The curriculum links to 17 stage notes. Each stage links to its courses. Each course links back to its stage. Note types have curriculum, study-stage, and course tags for optional graph grouping.
