---
title: "Tool and Fixture Design"
course_code: "MITECH 303"
stage: "12 Manufacturing digital fabrication CAD CAM and quality"
status: not-started
tags:
  - self-study
  - course
---

# Tool and Fixture Design

[[Stages/12 Manufacturing digital fabrication CAD CAM and quality|Back to stage]]

## Course reference

**Course code:** MITECH 303

**Course description:** Tool and Fixture Design

## Focus

Locating, clamping, workholding, and repeatable production

## Suggested textbook

Jig and Fixture Design - Edward Hoffman

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

