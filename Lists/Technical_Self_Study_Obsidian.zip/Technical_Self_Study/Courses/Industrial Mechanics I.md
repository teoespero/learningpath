---
title: "Industrial Mechanics I"
course_code: "IMMT 220"
stage: "9 Industrial mechanics instrumentation controls and robotics"
status: not-started
tags:
  - self-study
  - course
---

# Industrial Mechanics I

[[Stages/9 Industrial mechanics instrumentation controls and robotics|Back to stage]]

## Course reference

**Course code:** IMMT 220

**Course description:** Industrial Mechanics I

## Focus

Bearings, shafts, couplings, drives, and alignment

## Suggested textbook

Audel Millwrights and Mechanics Guide - Davis and Nelson

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

