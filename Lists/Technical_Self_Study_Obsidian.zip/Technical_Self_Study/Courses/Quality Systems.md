---
title: "Quality Systems"
course_code: "MITECH 310"
stage: "12 Manufacturing digital fabrication CAD CAM and quality"
status: not-started
tags:
  - self-study
  - course
---

# Quality Systems

[[Stages/12 Manufacturing digital fabrication CAD CAM and quality|Back to stage]]

## Course reference

**Course code:** MITECH 310

**Course description:** Quality Systems

## Focus

Process control, variation, planning, and improvement

## Suggested textbook

Introduction to Statistical Quality Control - Douglas Montgomery

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

