---
title: "Introduction to CAD/CAM Programming"
course_code: "MITECH 320"
stage: "12 Manufacturing digital fabrication CAD CAM and quality"
status: not-started
tags:
  - self-study
  - course
---

# Introduction to CAD/CAM Programming

[[Stages/12 Manufacturing digital fabrication CAD CAM and quality|Back to stage]]

## Course reference

**Course code:** MITECH 320

**Course description:** Introduction to CAD/CAM Programming

## Focus

Toolpaths, setups, machining operations, and simulation

## Suggested textbook

CNC Programming Handbook - Peter Smid; CAM tutorials

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

