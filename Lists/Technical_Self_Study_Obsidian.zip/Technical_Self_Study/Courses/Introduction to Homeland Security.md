---
title: "Introduction to Homeland Security"
course_code: "HLS 300"
stage: "15 Homeland security intelligence and infrastructure protection"
status: not-started
tags:
  - self-study
  - course
---

# Introduction to Homeland Security

[[Stages/15 Homeland security intelligence and infrastructure protection|Back to stage]]

## Course reference

**Course code:** HLS 300

**Course description:** Introduction to Homeland Security

## Focus

Threats, preparedness, response, and infrastructure protection

## Suggested textbook

Introduction to Homeland Security - Logan and Ramsay

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

