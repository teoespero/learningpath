---
title: "Introduction to Business Information Technology"
course_code: "BUSTEC 305"
stage: "1 Computing documentation and operating systems"
status: not-started
tags:
  - self-study
  - course
---

# Introduction to Business Information Technology

[[Stages/1 Computing documentation and operating systems|Back to stage]]

## Course reference

**Course code:** BUSTEC 305

**Course description:** Introduction to Business Information Technology

## Focus

Office applications, business data, and digital workflows

## Suggested textbook

Technology in Action - Evans, Martin, and Poatsy

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

