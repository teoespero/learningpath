---
title: "Python for Applied AI and Visualization"
course_code: "AI 311"
stage: "2 Programming databases and software development"
status: not-started
tags:
  - self-study
  - course
---

# Python for Applied AI and Visualization

[[Stages/2 Programming databases and software development|Back to stage]]

## Course reference

**Course code:** AI 311

**Course description:** Python for Applied AI and Visualization

## Focus

NumPy, data preparation, plotting, and notebooks

## Suggested textbook

Python Data Science Handbook - Jake VanderPlas

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

