---
title: "Microwave Communications Techniques"
course_code: "ET 400"
stage: "10 Electronic communications and microwave systems"
status: not-started
tags:
  - self-study
  - course
---

# Microwave Communications Techniques

[[Stages/10 Electronic communications and microwave systems|Back to stage]]

## Course reference

**Course code:** ET 400

**Course description:** Microwave Communications Techniques

## Focus

Propagation, antennas, link budgets, and transmission

## Suggested textbook

Electronic Communications: A System Approach - Beasley and Miller

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

