---
title: "Introduction to Biomedical Equipment Networking"
course_code: "BMET 261"
stage: "14 Biomedical equipment"
status: not-started
tags:
  - self-study
  - course
---

# Introduction to Biomedical Equipment Networking

[[Stages/14 Biomedical equipment|Back to stage]]

## Course reference

**Course code:** BMET 261

**Course description:** Introduction to Biomedical Equipment Networking

## Focus

Device networks, interfaces, reliability, and security

## Suggested textbook

Medical Instrumentation: Application and Design - Webster and Nimunkar; networking supplements

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

