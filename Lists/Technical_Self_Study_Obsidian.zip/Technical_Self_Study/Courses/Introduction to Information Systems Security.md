---
title: "Introduction to Information Systems Security"
course_code: "CISS 300"
stage: "5 Cybersecurity and recovery"
status: not-started
tags:
  - self-study
  - course
---

# Introduction to Information Systems Security

[[Stages/5 Cybersecurity and recovery|Back to stage]]

## Course reference

**Course code:** CISS 300

**Course description:** Introduction to Information Systems Security

## Focus

Threats, risk, controls, and responsibilities

## Suggested textbook

Principles of Information Security - Whitman and Mattord

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

