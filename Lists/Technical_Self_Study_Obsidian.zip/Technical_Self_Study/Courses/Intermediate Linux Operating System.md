---
title: "Intermediate Linux Operating System"
course_code: "CISC 324"
stage: "1 Computing documentation and operating systems"
status: not-started
tags:
  - self-study
  - course
---

# Intermediate Linux Operating System

[[Stages/1 Computing documentation and operating systems|Back to stage]]

## Course reference

**Course code:** CISC 324

**Course description:** Intermediate Linux Operating System

## Focus

Shell scripting, processes, automation, and administration

## Suggested textbook

How Linux Works - Brian Ward

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

