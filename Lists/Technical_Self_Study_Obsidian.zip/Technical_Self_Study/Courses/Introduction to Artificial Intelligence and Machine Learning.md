---
title: "Introduction to Artificial Intelligence and Machine Learning"
course_code: "AI 300"
stage: "7 Data science artificial intelligence and machine learning"
status: not-started
tags:
  - self-study
  - course
---

# Introduction to Artificial Intelligence and Machine Learning

[[Stages/7 Data science artificial intelligence and machine learning|Back to stage]]

## Course reference

**Course code:** AI 300

**Course description:** Introduction to Artificial Intelligence and Machine Learning

## Focus

Search, knowledge representation, learning, and applications

## Suggested textbook

Artificial Intelligence: A Modern Approach - Russell and Norvig; selected chapters

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

