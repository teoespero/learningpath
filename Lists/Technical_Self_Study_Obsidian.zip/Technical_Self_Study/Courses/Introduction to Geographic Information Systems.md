---
title: "Introduction to Geographic Information Systems"
course_code: "GEOG 330"
stage: "6 GIS spatial databases and remote sensing"
status: not-started
tags:
  - self-study
  - course
---

# Introduction to Geographic Information Systems

[[Stages/6 GIS spatial databases and remote sensing|Back to stage]]

## Course reference

**Course code:** GEOG 330

**Course description:** Introduction to Geographic Information Systems

## Focus

Spatial data models, coordinate systems, and GIS workflows

## Suggested textbook

Geographic Information Systems and Science - Longley and colleagues

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

