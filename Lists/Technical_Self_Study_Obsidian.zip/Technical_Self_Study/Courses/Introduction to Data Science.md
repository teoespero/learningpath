---
title: "Introduction to Data Science"
course_code: "CISD 357 / CISP 357"
stage: "7 Data science artificial intelligence and machine learning"
status: not-started
tags:
  - self-study
  - course
---

# Introduction to Data Science

[[Stages/7 Data science artificial intelligence and machine learning|Back to stage]]

## Course reference

**Course code:** CISD 357 / CISP 357

**Course description:** Introduction to Data Science

## Focus

Data questions, exploration, reproducibility, and communication

## Suggested textbook

Python Data Science Handbook - Jake VanderPlas

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

