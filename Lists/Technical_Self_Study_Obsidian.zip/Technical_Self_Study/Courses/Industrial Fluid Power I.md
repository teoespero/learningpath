---
title: "Industrial Fluid Power I"
course_code: "IMMT 240"
stage: "9 Industrial mechanics instrumentation controls and robotics"
status: not-started
tags:
  - self-study
  - course
---

# Industrial Fluid Power I

[[Stages/9 Industrial mechanics instrumentation controls and robotics|Back to stage]]

## Course reference

**Course code:** IMMT 240

**Course description:** Industrial Fluid Power I

## Focus

Hydraulic/pneumatic circuits, valves, and actuators

## Suggested textbook

Fluid Power with Applications - Anthony Esposito

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

