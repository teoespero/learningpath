---
title: "Information and Communication Technology Essentials A+"
course_code: "CISC 360"
stage: "1 Computing documentation and operating systems"
status: not-started
tags:
  - self-study
  - course
---

# Information and Communication Technology Essentials A+

[[Stages/1 Computing documentation and operating systems|Back to stage]]

## Course reference

**Course code:** CISC 360

**Course description:** Information and Communication Technology Essentials A+

## Focus

Computer components, hardware maintenance, and troubleshooting

## Suggested textbook

CompTIA A+ All-in-One Exam Guide - Mike Meyers and colleagues

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

