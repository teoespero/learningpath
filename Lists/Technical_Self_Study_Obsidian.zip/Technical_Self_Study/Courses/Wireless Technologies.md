---
title: "Wireless Technologies"
course_code: "CISN 336"
stage: "3 Networking foundations through advanced routing"
status: not-started
tags:
  - self-study
  - course
---

# Wireless Technologies

[[Stages/3 Networking foundations through advanced routing|Back to stage]]

## Course reference

**Course code:** CISN 336

**Course description:** Wireless Technologies

## Focus

RF fundamentals, WLAN design, coverage, and troubleshooting

## Suggested textbook

CWNA Certified Wireless Network Administrator Study Guide - Coleman and Westcott

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

