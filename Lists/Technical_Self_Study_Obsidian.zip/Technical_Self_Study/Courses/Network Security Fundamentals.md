---
title: "Network Security Fundamentals"
course_code: "CISS 310"
stage: "5 Cybersecurity and recovery"
status: not-started
tags:
  - self-study
  - course
---

# Network Security Fundamentals

[[Stages/5 Cybersecurity and recovery|Back to stage]]

## Course reference

**Course code:** CISS 310

**Course description:** Network Security Fundamentals

## Focus

Defenses, authentication, cryptography, and segmentation

## Suggested textbook

Network Security Essentials - William Stallings

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

