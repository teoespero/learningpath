---
title: "Materials and Processes"
course_code: "MITECH 301"
stage: "12 Manufacturing digital fabrication CAD CAM and quality"
status: not-started
tags:
  - self-study
  - course
---

# Materials and Processes

[[Stages/12 Manufacturing digital fabrication CAD CAM and quality|Back to stage]]

## Course reference

**Course code:** MITECH 301

**Course description:** Materials and Processes

## Focus

Material properties, selection, shaping, and methods

## Suggested textbook

Manufacturing Engineering and Technology - Kalpakjian and Schmid

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

