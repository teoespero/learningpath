---
title: "Mathematics for DC/AC Theory and Circuit Fundamentals"
course_code: "ET 314"
stage: "8 Electricity electronics and embedded computing"
status: not-started
tags:
  - self-study
  - course
---

# Mathematics for DC/AC Theory and Circuit Fundamentals

[[Stages/8 Electricity electronics and embedded computing|Back to stage]]

## Course reference

**Course code:** ET 314

**Course description:** Mathematics for DC/AC Theory and Circuit Fundamentals

## Focus

Mathematics applied to DC and AC circuits

## Suggested textbook

Technical Mathematics - John Bird

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

