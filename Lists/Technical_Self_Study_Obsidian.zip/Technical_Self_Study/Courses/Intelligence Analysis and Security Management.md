---
title: "Intelligence Analysis and Security Management"
course_code: "HLS 302"
stage: "15 Homeland security intelligence and infrastructure protection"
status: not-started
tags:
  - self-study
  - course
---

# Intelligence Analysis and Security Management

[[Stages/15 Homeland security intelligence and infrastructure protection|Back to stage]]

## Course reference

**Course code:** HLS 302

**Course description:** Intelligence Analysis and Security Management

## Focus

Sources, uncertainty, threats, and analytical findings

## Suggested textbook

Psychology of Intelligence Analysis - Richards Heuer

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

