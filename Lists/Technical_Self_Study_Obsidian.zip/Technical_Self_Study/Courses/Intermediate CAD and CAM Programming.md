---
title: "Intermediate CAD/CAM Programming"
course_code: "MITECH 321"
stage: "12 Manufacturing digital fabrication CAD CAM and quality"
status: not-started
tags:
  - self-study
  - course
---

# Intermediate CAD/CAM Programming

[[Stages/12 Manufacturing digital fabrication CAD CAM and quality|Back to stage]]

## Course reference

**Course code:** MITECH 321

**Course description:** Intermediate CAD/CAM Programming

## Focus

Geometry, tooling, machining strategies, and verification

## Suggested textbook

CNC Programming Handbook - Peter Smid

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

