---
title: "Technical Graphics With CAD I"
course_code: "EDT 310"
stage: "11 Engineering graphics CAD and building systems"
status: not-started
tags:
  - self-study
  - course
---

# Technical Graphics With CAD I

[[Stages/11 Engineering graphics CAD and building systems|Back to stage]]

## Course reference

**Course code:** EDT 310

**Course description:** Technical Graphics With CAD I

## Focus

Commands, layers, geometry, annotation, and plotting

## Suggested textbook

Technical Drawing with Engineering Graphics; software tutorials

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

