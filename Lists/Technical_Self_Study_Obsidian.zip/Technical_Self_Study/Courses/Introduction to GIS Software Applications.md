---
title: "Introduction to GIS Software Applications"
course_code: "GEOG 334"
stage: "6 GIS spatial databases and remote sensing"
status: not-started
tags:
  - self-study
  - course
---

# Introduction to GIS Software Applications

[[Stages/6 GIS spatial databases and remote sensing|Back to stage]]

## Course reference

**Course code:** GEOG 334

**Course description:** Introduction to GIS Software Applications

## Focus

Editing, geoprocessing, maps, and software practice

## Suggested textbook

GIS Tutorial for ArcGIS Pro - Gorr and Kurland

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

