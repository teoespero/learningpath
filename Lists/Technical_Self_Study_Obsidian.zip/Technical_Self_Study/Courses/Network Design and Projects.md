---
title: "Network Design and Projects"
course_code: "CISN 346"
stage: "3 Networking foundations through advanced routing"
status: not-started
tags:
  - self-study
  - course
---

# Network Design and Projects

[[Stages/3 Networking foundations through advanced routing|Back to stage]]

## Course reference

**Course code:** CISN 346

**Course description:** Network Design and Projects

## Focus

Requirements, topology, resilience, capacity, and documentation

## Suggested textbook

Top-Down Network Design - Priscilla Oppenheimer

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

