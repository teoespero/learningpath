---
title: "Technical Calculations"
course_code: "IMMT 130"
stage: "1 Computing documentation and operating systems"
status: not-started
tags:
  - self-study
  - course
---

# Technical Calculations

[[Stages/1 Computing documentation and operating systems|Back to stage]]

## Course reference

**Course code:** IMMT 130

**Course description:** Technical Calculations

## Focus

Measurements, ratios, formulas, and unit conversions

## Suggested textbook

Technical Mathematics - John Bird

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

