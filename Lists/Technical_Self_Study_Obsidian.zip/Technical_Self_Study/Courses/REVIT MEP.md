---
title: "REVIT MEP"
course_code: "EDT 317"
stage: "11 Engineering graphics CAD and building systems"
status: not-started
tags:
  - self-study
  - course
---

# REVIT MEP

[[Stages/11 Engineering graphics CAD and building systems|Back to stage]]

## Course reference

**Course code:** EDT 317

**Course description:** REVIT MEP

## Focus

Model and coordinate mechanical, electrical, and plumbing systems

## Suggested textbook

Autodesk Revit MEP Fundamentals - ASCENT

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

