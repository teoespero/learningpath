---
title: "Semiconductors and Nanotechnology"
course_code: "ET 322"
stage: "8 Electricity electronics and embedded computing"
status: not-started
tags:
  - self-study
  - course
---

# Semiconductors and Nanotechnology

[[Stages/8 Electricity electronics and embedded computing|Back to stage]]

## Course reference

**Course code:** ET 322

**Course description:** Semiconductors and Nanotechnology

## Focus

Diodes, transistors, semiconductor behavior, and applications

## Suggested textbook

Electronic Devices - Thomas Floyd; nanotechnology supplements

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

