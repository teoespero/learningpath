---
title: "REVIT Architectural"
course_code: "EDT 316"
stage: "11 Engineering graphics CAD and building systems"
status: not-started
tags:
  - self-study
  - course
---

# REVIT Architectural

[[Stages/11 Engineering graphics CAD and building systems|Back to stage]]

## Course reference

**Course code:** EDT 316

**Course description:** REVIT Architectural

## Focus

Building information modeling and architectural documentation

## Suggested textbook

Autodesk Revit for Architecture: No Experience Required - Eric Wing

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

