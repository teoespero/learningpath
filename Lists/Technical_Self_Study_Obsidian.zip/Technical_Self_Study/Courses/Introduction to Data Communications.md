---
title: "Introduction to Data Communications"
course_code: "CISC 355"
stage: "3 Networking foundations through advanced routing"
status: not-started
tags:
  - self-study
  - course
---

# Introduction to Data Communications

[[Stages/3 Networking foundations through advanced routing|Back to stage]]

## Course reference

**Course code:** CISC 355

**Course description:** Introduction to Data Communications

## Focus

Signals, transmission, protocols, and communications models

## Suggested textbook

Data Communications and Networking - Behrouz Forouzan

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

