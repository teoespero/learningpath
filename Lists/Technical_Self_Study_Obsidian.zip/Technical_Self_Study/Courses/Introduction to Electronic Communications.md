---
title: "Introduction to Electronic Communications"
course_code: "ET 380"
stage: "10 Electronic communications and microwave systems"
status: not-started
tags:
  - self-study
  - course
---

# Introduction to Electronic Communications

[[Stages/10 Electronic communications and microwave systems|Back to stage]]

## Course reference

**Course code:** ET 380

**Course description:** Introduction to Electronic Communications

## Focus

Modulation, transmitters, receivers, noise, and antennas

## Suggested textbook

Principles of Electronic Communication Systems - Louis Frenzel

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

