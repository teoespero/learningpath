---
title: "Mathematics for Circuit Analysis"
course_code: "ET 312"
stage: "8 Electricity electronics and embedded computing"
status: not-started
tags:
  - self-study
  - course
---

# Mathematics for Circuit Analysis

[[Stages/8 Electricity electronics and embedded computing|Back to stage]]

## Course reference

**Course code:** ET 312

**Course description:** Mathematics for Circuit Analysis

## Focus

Algebra, trigonometry, complex numbers, and calculations

## Suggested textbook

Technical Mathematics - John Bird

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

