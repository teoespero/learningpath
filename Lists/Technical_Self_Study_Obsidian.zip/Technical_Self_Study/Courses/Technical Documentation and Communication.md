---
title: "Technical Documentation and Communication"
course_code: "IMMT 120"
stage: "1 Computing documentation and operating systems"
status: not-started
tags:
  - self-study
  - course
---

# Technical Documentation and Communication

[[Stages/1 Computing documentation and operating systems|Back to stage]]

## Course reference

**Course code:** IMMT 120

**Course description:** Technical Documentation and Communication

## Focus

Procedures, diagrams, records, and technical reports

## Suggested textbook

Technical Communication - Markel and Selber

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

