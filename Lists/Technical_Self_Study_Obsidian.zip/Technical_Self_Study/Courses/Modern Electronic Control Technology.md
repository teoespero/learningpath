---
title: "Modern Electronic Control Technology"
course_code: "ET 362"
stage: "9 Industrial mechanics instrumentation controls and robotics"
status: not-started
tags:
  - self-study
  - course
---

# Modern Electronic Control Technology

[[Stages/9 Industrial mechanics instrumentation controls and robotics|Back to stage]]

## Course reference

**Course code:** ET 362

**Course description:** Modern Electronic Control Technology

## Focus

Sensors, feedback, analog/digital controls, and PLCs

## Suggested textbook

Process Control Instrumentation Technology - Curtis Johnson

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

