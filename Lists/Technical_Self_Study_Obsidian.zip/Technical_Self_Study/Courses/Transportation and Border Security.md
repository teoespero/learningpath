---
title: "Transportation and Border Security"
course_code: "HLS 304"
stage: "15 Homeland security intelligence and infrastructure protection"
status: not-started
tags:
  - self-study
  - course
---

# Transportation and Border Security

[[Stages/15 Homeland security intelligence and infrastructure protection|Back to stage]]

## Course reference

**Course code:** HLS 304

**Course description:** Transportation and Border Security

## Focus

Infrastructure, vulnerabilities, protection, and resilience

## Suggested textbook

Introduction to Transportation Security - Edwards and Goodrich

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

