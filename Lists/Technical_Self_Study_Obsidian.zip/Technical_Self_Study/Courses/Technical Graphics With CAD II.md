---
title: "Technical Graphics With CAD II"
course_code: "EDT 312"
stage: "11 Engineering graphics CAD and building systems"
status: not-started
tags:
  - self-study
  - course
---

# Technical Graphics With CAD II

[[Stages/11 Engineering graphics CAD and building systems|Back to stage]]

## Course reference

**Course code:** EDT 312

**Course description:** Technical Graphics With CAD II

## Focus

Blocks, references, drawing organization, and complex plans

## Suggested textbook

AutoCAD and Its Applications Comprehensive - Goodheart-Willcox

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

