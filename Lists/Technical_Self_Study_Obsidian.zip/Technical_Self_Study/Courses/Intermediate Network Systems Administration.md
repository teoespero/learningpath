---
title: "Intermediate Network Systems Administration"
course_code: "CISN 302"
stage: "4 Servers infrastructure virtualization and cloud"
status: not-started
tags:
  - self-study
  - course
---

# Intermediate Network Systems Administration

[[Stages/4 Servers infrastructure virtualization and cloud|Back to stage]]

## Course reference

**Course code:** CISN 302

**Course description:** Intermediate Network Systems Administration

## Focus

Server roles, policies, permissions, and services

## Suggested textbook

Mastering Windows Server - Jordan Krause

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

