---
title: "Virtualization Concepts and Technologies"
course_code: "CISN 316"
stage: "4 Servers infrastructure virtualization and cloud"
status: not-started
tags:
  - self-study
  - course
---

# Virtualization Concepts and Technologies

[[Stages/4 Servers infrastructure virtualization and cloud|Back to stage]]

## Course reference

**Course code:** CISN 316

**Course description:** Virtualization Concepts and Technologies

## Focus

Hypervisors, virtual networking, storage, and virtual machines

## Suggested textbook

Mastering VMware vSphere - Nick Marshall and colleagues

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

