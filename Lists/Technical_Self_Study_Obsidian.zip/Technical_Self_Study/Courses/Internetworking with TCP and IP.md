---
title: "Internetworking with TCP/IP"
course_code: "CISN 308"
stage: "3 Networking foundations through advanced routing"
status: not-started
tags:
  - self-study
  - course
---

# Internetworking with TCP/IP

[[Stages/3 Networking foundations through advanced routing|Back to stage]]

## Course reference

**Course code:** CISN 308

**Course description:** Internetworking with TCP/IP

## Focus

TCP/IP behavior, addressing, routing, and packet analysis

## Suggested textbook

TCP/IP Illustrated, Volume 1 - Fall and Stevens

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

