---
title: "Integrated Circuits with Computer Applications"
course_code: "ET 335"
stage: "8 Electricity electronics and embedded computing"
status: not-started
tags:
  - self-study
  - course
---

# Integrated Circuits with Computer Applications

[[Stages/8 Electricity electronics and embedded computing|Back to stage]]

## Course reference

**Course code:** ET 335

**Course description:** Integrated Circuits with Computer Applications

## Focus

Analog/digital ICs, amplification, and interfaces

## Suggested textbook

Electronics Fundamentals: Circuits, Devices & Applications - Floyd and Buchla

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

