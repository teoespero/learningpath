---
title: "Introduction to Computer Information Science"
course_code: "CISC 310"
stage: "1 Computing documentation and operating systems"
status: not-started
tags:
  - self-study
  - course
---

# Introduction to Computer Information Science

[[Stages/1 Computing documentation and operating systems|Back to stage]]

## Course reference

**Course code:** CISC 310

**Course description:** Introduction to Computer Information Science

## Focus

Computing concepts, hardware, software, and information systems

## Suggested textbook

Computer Science: An Overview - Brookshear and Brylow

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

