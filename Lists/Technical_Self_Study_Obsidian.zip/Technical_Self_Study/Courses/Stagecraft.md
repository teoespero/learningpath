---
title: "Stagecraft"
course_code: "TA 420"
stage: "16 Making entrepreneurship education and creative electives"
status: not-started
tags:
  - self-study
  - course
---

# Stagecraft

[[Stages/16 Making entrepreneurship education and creative electives|Back to stage]]

## Course reference

**Course code:** TA 420

**Course description:** Stagecraft

## Focus

Construction methods, materials, tools, and production

## Suggested textbook

The Backstage Handbook - Paul Carter

## Study checklist

- [ ] Review the topics and prerequisites
- [ ] Choose reading material
- [ ] Complete reading and exercises
- [ ] Complete a practical project
- [ ] Write a summary of what I learned

## Study notes


## Exercises and projects


## Questions to revisit


## Resources

